#ifndef __EXTENDED_DOT_H__
#define __EXTENDED_DOT_H__

extern int do_indirect_extended(char *diebuf, struct iinfo *iinf);
extern int display_extended(void);

#endif

