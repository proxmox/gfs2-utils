#ifndef __CONFIG_DOT_H__
#define __CONFIG_DOT_H__

#define DEFAULT_DEBUG_LOGFILE 0
#define DEFAULT_ENABLE_WITHDRAW 1

extern int optd_debug_logfile;
extern int optd_enable_withdraw;

extern int cfgd_debug_logfile;
extern int cfgd_enable_withdraw;

#endif

