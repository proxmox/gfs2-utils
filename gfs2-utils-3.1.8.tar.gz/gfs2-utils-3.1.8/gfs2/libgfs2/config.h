#ifndef __LGFS2_CONFIG_H__
#define __LGFS2_CONFIG_H__

extern int cfg_debug;

#endif /* __LGFS2_CONFIG_H__ */
